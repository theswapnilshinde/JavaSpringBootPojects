package com.netprizm.app.service.impl;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.netprizm.app.entity.TowerData;
import com.netprizm.app.repositary.TowerRepositary;
import com.netprizm.app.service.TowerService;
@Service
public class TowerServiceImpl implements TowerService  {

	private TowerRepositary towerRepositary;
	@Override
	public String editCourse(TowerData towerData) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String add(TowerData towerData) {
		towerRepositary.save(towerData);
		return "success";
	}

	@Override
	public String deleteTowerData(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
