package com.netprizm.app.io.dto;

import lombok.Data;
@Data
public class UesDto {
	
	private int startPointX ;
	private int startPointY;
	private int startTime;
	private int ueId ;
	private int ueInfoId;

}