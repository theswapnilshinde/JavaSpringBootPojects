package com.netprizm.app.repositary;

import org.springframework.data.jpa.repository.JpaRepository;

import com.netprizm.app.entity.Template;

public interface TemplateRepo extends JpaRepository<Template, Integer> {

}
