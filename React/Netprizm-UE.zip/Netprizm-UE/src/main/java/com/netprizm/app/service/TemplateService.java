package com.netprizm.app.service;


import com.netprizm.app.TieClass.TemplateRequestDto;
import com.netprizm.app.entity.Template;
import com.netprizm.app.entity.TowerData;
import com.netprizm.app.io.dto.TemplateDto;

public interface TemplateService {
	
	String CreateTemplate(Template template);

	String deleteTowerData(int id);

	String save(TemplateRequestDto requestTemplate);
	TemplateDto saveDto(TemplateDto requestTemplate);


}
