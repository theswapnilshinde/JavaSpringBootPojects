package com.netprizm.app.service;


import com.netprizm.app.entity.TowerData;

public interface TowerService {
	
	String editCourse(TowerData towerData);
	
	String add(TowerData towerData);

	String deleteTowerData(int id);

}
