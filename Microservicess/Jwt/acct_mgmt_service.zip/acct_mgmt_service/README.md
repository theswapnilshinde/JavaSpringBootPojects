# Account Management Service for Netprizm
The account management micro-service for Netprizm is used to handle user authentication. 

This project uses:
   - Java 16
   - Maven 3.8
   - Springboot 2.4

<p><br/></p>


## Getting Started

#### Project Setup
After cloning the project `git clone https://gitlab.vzsme.com/netprizm2/services/acct-mgmt-service.git`,
you need to setup some files in the project which **SHOULD NOT** be checked into source control.
 - `.idea/workspace.xml`
 - `src/main/resources/application.properties`

**NOTE:** Run the script `.setup.cmd` to create these files automatically for you.  
<p><br/></p>



#### Build and Run `Shift+F10`
The following instruction are based on IntelliJ IDEA (Community Edition).  
 - `mvn clean install -U -Dmaven.test.skip=true`
 - `mvn package -Dmaven.test.skip=true`
 - `mvn spring-boot:start`
 - `mvn spring-boot:run`

**NOTE:** If the project fails to run: Select the **pom.xml** file then right-click and
select the **Maven > Reimport** option.

Your service will be available at port **9099** and can be accessed:
`http://localhost:9099/acct-mgmt-service/api/v1/version`

Use Postman to verify the system works:
`GET: http://localhost:902/acct-mgmt-service/api/v1/version`


<p><br/></p>

#### REST API Specifications
The following URL documents the REST API for this service:
``` http://localhost:9099/acct-mgmt-service/swagger-ui.html ``` 

<p><br/><br/></p>
 
 ## Deployment
This service project is based on existing micro-service projects in which 
the DevOps team has already created automated deployment scripts. Therefore, let
them know your new service name and any application properties tokens that need 
to be set for each environment. 