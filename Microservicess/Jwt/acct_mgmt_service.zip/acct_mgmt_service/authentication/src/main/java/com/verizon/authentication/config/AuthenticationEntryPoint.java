package com.verizon.authentication.config;

public interface AuthenticationEntryPoint {
}
