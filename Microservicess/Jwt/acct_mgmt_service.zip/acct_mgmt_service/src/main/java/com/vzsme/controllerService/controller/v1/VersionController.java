package com.vzsme.controllerService.controller.v1;

import com.vzsme.controllerService.AppConfigProperties;
import com.vzsme.controllerService.controller.v1.response.GetVersionResponse;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

public class VersionController extends BaseController {

    @Autowired
    protected AppConfigProperties appConfig;

    @ApiOperation(value = "Get the version information for this service") //, tags = "Admin")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK")
    })
    @RequestMapping(value = UriConstantsV1.version, method = RequestMethod.GET)
    //@RequestMapping(value = "", method = RequestMethod.GET)
    public GetVersionResponse getVersion(
            HttpServletRequest request)
    {
        String version = appConfig.props.getVersion();
        String name = appConfig.props.getName();
        String desc = appConfig.props.getDescription();

        return new GetVersionResponse(
                version,
                String.format("%s", name).trim(), // Name
                String.format("%s",desc).trim()  // Description
        );
    }
}
