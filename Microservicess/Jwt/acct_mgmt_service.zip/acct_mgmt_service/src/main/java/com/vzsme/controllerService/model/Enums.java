package com.vzsme.controllerService.model;

import java.util.Map;
import static java.util.Arrays.stream;
import static java.util.stream.Collectors.toMap;


public class Enums {

    public enum UserType {
        None(0),
        Netprizm(1),
        VZLDAP(2);

        private final int userTypeNo;

        private final static Map<Integer, UserType> map =
                stream(UserType.values()).collect(toMap(st -> st.userTypeNo, st -> st));

        private UserType(final int nRFreqBandTypeNo) {
            this.userTypeNo = nRFreqBandTypeNo;
        }

        public static UserType valueOf(int userTypeNo) {
            return map.get(userTypeNo);
        }

        public int getUserTypeNo() {
            return userTypeNo;
        }

        @Override
        public String toString() {
            return this.name();

        }
    }

}
