package com.vzsme.controllerService.model.AppProperties;

import org.springframework.stereotype.Component;

@Component
public class DatabaseProps {
    public String url;
    public String user;
    public String password;

    public void setUrl(String value) { this.url = value; }
    public void setUser(String value) { this.user = value; }
    public void setPassword(String value) { this.password = value; }
}
