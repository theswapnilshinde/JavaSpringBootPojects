package com.vzsme.controllerService.controller.v1.request;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

public class UserLoginRequest {
    @NotNull(message = "is required")
    @Valid public String loginName;

    @NotNull(message = "is required")
    @Valid public String loginPassword;

    // Optional: If provided then this is an auto login if not expired!
    public String currentToken;

    public void validateInput() {
        //throw new InvalidInputException(">>> TESTING <<<<<");
    }
}
