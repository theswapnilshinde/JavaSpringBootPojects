package com.vzsme.controllerService.controller.v1.request;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

public class CreateUserRequest {
    @NotNull(message = "is required")
    @Valid public String adminPassword;

    @NotNull(message = "is required")
    @Valid public String loginName;

    @NotNull(message = "is required")
    @Valid public String loginPassword;

    @NotNull(message = "is required")
    @Valid public String firstName;

    @NotNull(message = "is required")
    @Valid public String lastName;

    public void validateInput() {
        //throw new InvalidInputException(">>> TESTING <<<<<");
    }
}
