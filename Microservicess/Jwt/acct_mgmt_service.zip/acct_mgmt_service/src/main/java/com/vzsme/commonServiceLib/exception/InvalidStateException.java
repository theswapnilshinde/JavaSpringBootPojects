package com.vzsme.commonServiceLib.exception;

import com.vzsme.commonServiceLib.exception.base.BaseApiException;
import org.springframework.http.HttpStatus;

public class InvalidStateException extends BaseApiException {
    public InvalidStateException(String message) {
        super(HttpStatus.CONFLICT, "Invalid State", message); //409
    }
}
