package com.vzsme.controllerService.controller.v1.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.vzsme.controllerService.model.UserLoginDto;

import java.util.Date;

@JsonInclude(JsonInclude.Include.NON_NULL) // Null items are not sent in response
public class UserLoginResponse {
    public String userFirstName;
    public String userLastName;
    public String loginName;
    public String token;
    public Date lastLoginUTC;
    public Date tokenExpireDateUTC;

    public UserLoginResponse(UserLoginDto userDto) {
        // NOTE: The ID nor the password should be sent back. Private information!
        this.loginName = userDto.loginName;
        this.userFirstName = userDto.userFirstName;
        this.userLastName = userDto.userLastName;
        this.token = userDto.token;
        this.lastLoginUTC = userDto.lastLoginUTC;
        this.tokenExpireDateUTC = userDto.tokenExpireDateUTC;
    }
}
