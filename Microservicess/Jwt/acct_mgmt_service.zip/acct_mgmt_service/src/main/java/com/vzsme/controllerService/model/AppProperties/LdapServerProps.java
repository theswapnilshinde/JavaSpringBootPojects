package com.vzsme.controllerService.model.AppProperties;

public class LdapServerProps {
    public String url;
    public String domain;
    public String rootDn;

    public boolean enableSecurity=false;
    public boolean msActiveDirectory=true;

    public LdapServerProps() { }

    public void setUrl(String value) {
        this.url = value;
    }
    public void setDomain(String value) {
        this.domain = value;
    }
    public void setRootDn(String value) {
        this.rootDn = value;
    }
    public void setEnableSecurity(boolean value) {
        this.enableSecurity = value;
    }
    public void setMsActiveDirectory(boolean value) { this.msActiveDirectory = value; }
}
