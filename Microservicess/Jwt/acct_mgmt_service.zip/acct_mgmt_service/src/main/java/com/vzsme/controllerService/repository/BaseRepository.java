package com.vzsme.controllerService.repository;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzsme.controllerService.AppConfigProperties;
import com.vzsme.controllerService.model.PagedList;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;
import java.util.Map;
import java.util.function.Consumer;

@Repository
public class BaseRepository {

    private int duration;
    private String jwtSecret;

    protected String dbUrl;
    protected String dbUser;
    protected String dbPassword;

    @Autowired
    private AppConfigProperties appProps;

    @PostConstruct
    public void init() {
        dbUrl = appProps.db.url;
        dbUser = appProps.db.user;
        dbPassword = appProps.db.password;

        jwtSecret = appProps.token.jwtSecret;
        duration = appProps.token.jwtExpirationInMinutes * 1000 * 60;
        //userType = (appConfig.ldap.enableSecurity ? EmulationEnums.UserType.VZLDAP : EmulationEnums.UserType.Netprizm);
    }


    // JsonWebToken generator
    protected Token createToken(String loginName) {
        return new Token(loginName);
    }
    class Token {
        String value;
        java.util.Date issuedDate;
        java.util.Date expiryDate;

        public Token(String loginName) {
            // NOTE: UTC because this application was set to UTC when started.
            this.issuedDate = new java.util.Date();
            this.expiryDate = new java.util.Date(issuedDate.getTime() + duration);

            this.value = Jwts.builder()
                    .setSubject(loginName.toLowerCase())
                    .setIssuedAt(issuedDate)
                    .setExpiration(expiryDate)
                    .signWith(SignatureAlgorithm.HS512, jwtSecret)
                    .compact();
        }
    }


    protected String convertHashMap(Object json) throws Exception {
        return (json == null ? null : new ObjectMapper().writeValueAsString(json));
    }

    protected Map<String, Object> convertJson(ResultSet rs, String column) throws Exception {
        String json = rs.getString(column);
        return (json == null ? null : this.convertJson(new JSONObject(json)));
    }
    private Map<String, Object> convertJson(JSONObject json) throws Exception {
        return (json == null ? null : new ObjectMapper().readValue(json.toString(), new TypeReference<Map<String, Object>>() {}));
    }


    ///
    /// Helper method to get a paged list of items from the database
    ///
    protected PagedList retrievePagedList(PagedList list, String sqlCnt, String sqlQry, Object[] params, Consumer<ResultSet> callback) throws Exception {
        int pageLimit = list.getLimit();
        int pageOffset = ((list.getOffset() - 1) * pageLimit);

        try (Connection con = DriverManager.getConnection(dbUrl, dbUser, dbPassword)) {
            try (PreparedStatement stCnt = con.prepareStatement(sqlCnt)) {
                this.setQueryParams(stCnt, params);
                try (ResultSet rsCnt = stCnt.executeQuery()) {
                    if (rsCnt.next()) {
                        list.setTotalCount(rsCnt.getInt(1));
                    }
                }
            }
            if (list.getTotalCount() > 0) {
                sqlQry = sqlQry.replace(";", "").trim();
                sqlQry += " OFFSET ? FETCH NEXT ? ROWS ONLY";
                try (PreparedStatement stQry = con.prepareStatement(sqlQry)) {
                    var ndx = this.setQueryParams(stQry, params);
                    stQry.setInt(ndx++, pageOffset);
                    stQry.setInt(ndx++, pageLimit);
                    try (ResultSet rs = stQry.executeQuery()) {
                        while (rs.next()) {
                            // By default the result set cursor is before the first row.
                            // Make sure we are on the first row and we have data.
                            if (rs.isBeforeFirst()) {
                                if (!rs.first()) {
                                    continue;
                                }
                            }
                            callback.accept(rs); // Read from result item and add to list
                        }
                    }
                }
            }
        }
        return list;
    }

    private int setQueryParams(PreparedStatement stQry, Object[] params) throws Exception
    {
        int ndx = 1;
        if (params != null) {
            for (int i = 0; i < params.length; i++, ndx++) {
                Object p = params[i];
                if (p != null) {
                    if (p instanceof Integer)
                        stQry.setInt(ndx, ((Integer) p).intValue());
                    else
                        stQry.setString(ndx, (String) p);
                }
            }
        }
        return ndx;
    }
}
