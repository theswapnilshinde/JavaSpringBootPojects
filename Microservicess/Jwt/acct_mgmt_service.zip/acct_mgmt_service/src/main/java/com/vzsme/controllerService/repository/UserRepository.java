package com.vzsme.controllerService.repository;

import com.vzsme.commonServiceLib.exception.DbQueryException;
import com.vzsme.commonServiceLib.exception.ItemExistsException;
import com.vzsme.commonServiceLib.exception.UnauthorizedException;
import com.vzsme.controllerService.model.Enums;
import com.vzsme.controllerService.model.UserLoginDto;
import org.springframework.stereotype.Repository;

import java.sql.*;
import java.time.LocalDateTime;

@Repository
public class UserRepository extends BaseRepository {


    public UserLoginDto createUser(String loginName, String loginPwd, String firstName, String lastName)  {
        loginName = loginName.trim().toLowerCase();
        var token = super.createToken(loginName);

        String sqlSelect = "SELECT id from acct.user WHERE loginName = ?";
        String sqlInsert = " INSERT INTO acct.user(loginName, loginPwd, firstname, lastname, isactive, adminlevel, pwdneedsreset, lastlogin, logintoken, tokenExpires) values(?, acct.crypt(?, acct.gen_salt('bf', 8)), ?, ?, ?, ?, ?, ?, ?, ?) RETURNING *; ";

        try (Connection con = DriverManager.getConnection(dbUrl, dbUser, dbPassword)) {
            //
            // First, make sure a entry does NOT already exist with this user name.
            //
            PreparedStatement st1 = con.prepareStatement(sqlSelect);
            st1.setString(1, loginName);
            if (st1.executeQuery().next()) {
                throw new ItemExistsException("Entry already exists with this user name.");
            }

            //
            // Crete the user.
            //
            int ndx = 1;
            PreparedStatement st = con.prepareStatement(sqlInsert);
            st.setString(ndx++, loginName);
            st.setString(ndx++, loginPwd);
            st.setString(ndx++, firstName);
            st.setString(ndx++, lastName);
            st.setBoolean(ndx++, true); // active
            st.setInt(ndx++, 1); // Admin level
            st.setBoolean(ndx++, false); // pwd needs reset
            st.setTimestamp(ndx++, new java.sql.Timestamp(token.issuedDate.getTime())); // UTC
            st.setString(ndx++, token.value);
            st.setTimestamp(ndx++, new java.sql.Timestamp(token.expiryDate.getTime())); // UTC

            ResultSet rs = st.executeQuery();
            if (!rs.next()) {
                throw new DbQueryException("User was not created.", null);
            }

            return readUserDto(rs);

        } catch (SQLException ex) {
            String msg = String.format("Failed to create user with login name: '%s'", loginName);
            System.err.println(msg);
            ex.printStackTrace();
            throw new DbQueryException(msg, ex);
        }
    }

    public UserLoginDto getByLoginToken(String loginName, String token, Enums.UserType userType) {
        loginName = loginName.trim().toLowerCase();

        String sql = "SELECT id, loginName, firstname, lastname, isactive, pwdNeedsReset, lastlogin, logintoken, tokenExpires from acct.user where loginName = ? and loginToken=? and userType=?;";

        try (Connection con = DriverManager.getConnection(dbUrl, dbUser, dbPassword)) {
            int ndx=1;
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(ndx++, loginName);
            st.setString(ndx++, token);
            st.setInt(ndx++, userType.getUserTypeNo());

            ResultSet rs = st.executeQuery();
            if (!rs.next()) {
                throw new UnauthorizedException("Your token is invalid. Please login again.");
            }

            return readUserDto(rs);

        } catch (SQLException ex) {
            String msg = String.format("Failed to get user by token for login name: '%s'", loginName);
            System.err.println(msg);
            ex.printStackTrace();
            throw new DbQueryException(msg, ex);
        }
    }


    public UserLoginDto getByCredentials(String loginName, String loginPwd) {
        loginName = loginName.trim().toLowerCase();

        String selectSql = "SELECT id, loginName, firstName, lastName, isActive, pwdNeedsReset, lastLogin, loginToken, tokenExpires FROM acct.user WHERE loginName = ? and loginPwd = acct.crypt(?, loginPwd) and usertype=1";
        String updateSql = "UPDATE acct.user set lastLogin=?, loginToken=?, tokenExpires=? where id=?";

        int ndx=1;
        var retUser = new UserLoginDto();
        try (Connection con = DriverManager.getConnection(dbUrl, dbUser, dbPassword)) {
            PreparedStatement st1 = con.prepareStatement(selectSql);
            st1.setString(ndx++, loginName);
            st1.setString(ndx++, loginPwd);

            ResultSet rs = st1.executeQuery();
            if (!rs.next()) {
                throw new UnauthorizedException("Invalid login name or password provided.");
            }

            readUserDto(rs, retUser);
            if (retUser != null) {
                ndx=1;
                var token = createToken(loginName);
                PreparedStatement st2 = con.prepareStatement(updateSql);
                st2.setTimestamp(ndx++, new java.sql.Timestamp(token.issuedDate.getTime())); // UTC
                st2.setString(ndx++, token.value);
                st2.setTimestamp(ndx++, new java.sql.Timestamp(token.expiryDate.getTime())); // UTC
                st2.setLong(ndx++, retUser.id);

                st2.executeUpdate();

                // Update response
                retUser.token = token.value;
                retUser.tokenExpireDateUTC = token.expiryDate;
                retUser.lastLoginUTC = token.issuedDate;

            }

            return retUser;

        } catch (SQLException ex) {
            String msg = String.format("Failed to get user by credentials for login name: '%s'", loginName);
            System.err.println(msg);
            ex.printStackTrace();
            throw new DbQueryException(msg, ex);
        }
    }

    private UserLoginDto readUserDto(ResultSet rs) throws SQLException {
        return this.readUserDto(rs, new UserLoginDto());
    }
    private UserLoginDto readUserDto(ResultSet rs, UserLoginDto dto) throws SQLException {
        dto.id = rs.getInt("id");
        dto.loginName = rs.getString("loginName");
        dto.userFirstName = rs.getString("firstname");
        dto.userLastName = rs.getString("lastname");
        dto.isActive = rs.getBoolean("isActive");
        dto.pwdNeedsReset = rs.getBoolean("pwdNeedsReset");
        dto.lastLoginUTC = rs.getTimestamp("lastLogin");
        dto.token = rs.getString("loginToken");
        dto.tokenExpireDateUTC = rs.getTimestamp("tokenExpires");

        return dto;
    }

}
