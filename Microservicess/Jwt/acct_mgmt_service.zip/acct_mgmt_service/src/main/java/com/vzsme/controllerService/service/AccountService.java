package com.vzsme.controllerService.service;


import com.vzsme.commonServiceLib.exception.UnauthorizedException;
import com.vzsme.controllerService.controller.v1.request.CreateUserRequest;
import com.vzsme.controllerService.controller.v1.request.UserLoginRequest;
import com.vzsme.controllerService.controller.v1.response.UserLoginResponse;
import com.vzsme.controllerService.model.Enums;
import com.vzsme.controllerService.model.UserLoginDto;
import com.vzsme.controllerService.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class AccountService extends BaseService {

    @Autowired
    private UserRepository userRepo;

    public UserLoginResponse createUser(CreateUserRequest request)  {
        request.validateInput();  // Validate Input - throws 400 BAD_REQUEST
        try {
            System.out.println(String.format("**** Received request for: CreateUser '%s'", request.loginName));
            return doCreateUser(request);
        } finally {
            System.out.println(String.format("**** Request complete for: CreateUser '%s'", request.loginName));
        }
    }

    public UserLoginResponse loginUser(UserLoginRequest request)  {
        request.validateInput();  // Validate Input - throws 400 BAD_REQUEST

        try {
            System.out.println(String.format("**** Received request for: UserLogin '%s'", request.loginName));
            if (request.currentToken != null) {
                return doAutoLogin(request);
            } else {
                return doLogin(request);
            }
        } finally {
            System.out.println(String.format("**** Request complete for: UserLogin '%s'", request.loginName));
        }
    }


    private UserLoginResponse validateLogin(UserLoginDto userDto) {
        if (!userDto.isActive) {
            throw new UnauthorizedException("User is not active.");
        }
        if (userDto.pwdNeedsReset) {
            throw new UnauthorizedException("Password needs to be reset.");
        }
        validateToken(userDto.token); // Throws if expired or not valid
        return new UserLoginResponse(userDto);
    }
    private  UserLoginResponse doAutoLogin(UserLoginRequest request) {
        var userDto = userRepo.getByLoginToken(request.loginName, request.currentToken, Enums.UserType.Netprizm);
        return validateLogin(userDto);
    }
    private  UserLoginResponse doLogin(UserLoginRequest request) {
        var userDto = userRepo.getByCredentials(request.loginName, request.loginPassword);
        return validateLogin(userDto);
    }


    private UserLoginResponse doCreateUser(CreateUserRequest request) {
        if (!request.adminPassword.equals(appConfig.token.adminPwd)) {
            throw new UnauthorizedException("Invalid admin password provided.");
        }
        var userDto = userRepo.createUser(request.loginName, request.loginPassword, request.firstName, request.lastName);
        return new UserLoginResponse(userDto);
    }

}

