package com.vzsme.controllerService.model.AppProperties;

public class TokenProps {
    public String adminPwd;
    public String jwtSecret;
    public int jwtExpirationInMinutes=720;  // 12x60=720

    public TokenProps() { }

    public void setAdminPwd(String value) {
        this.adminPwd = value;
    }
    public void setJwtSecret(String value) {
        this.jwtSecret = value;
    }
    public void setJwtExpirationInMinutes(int value) { this.jwtExpirationInMinutes = value;  }
}
