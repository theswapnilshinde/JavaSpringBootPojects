package com.vzsme.controllerService.model;

import java.util.ArrayList;

public class PagedList<T> {
    private int offset;
    private int limit;
    private long totalCount;
    private long pageCount;
    private ArrayList<T> list;

    public PagedList(int offset, int limit)
    {
        this.offset = offset;
        this.limit = limit;
        this.totalCount = 0;
        this.pageCount = 0;
        this.list = new ArrayList<T>();
    }

    public int getLimit() { return limit; }
    public int getOffset() { return offset; }

    public long getTotalCount() {
        return totalCount;
    }
    public void setTotalCount(long totalCount) {
        this.totalCount = totalCount;
        this.pageCount = (totalCount / limit) + (totalCount % limit > 0 ? 1 : 0);
    }

    public ArrayList<T> getList() {
        return list;
    }
    public void setList(ArrayList<T> list) {
        this.list = list;
    }

}
