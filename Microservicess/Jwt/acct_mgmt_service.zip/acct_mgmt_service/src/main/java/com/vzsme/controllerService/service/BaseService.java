package com.vzsme.controllerService.service;

import com.vzsme.controllerService.AppConfigProperties;
import com.vzsme.commonServiceLib.exception.UnauthorizedException;
import io.jsonwebtoken.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.Date;

import io.jsonwebtoken.Jwts;


@Service
public class BaseService {

    private String jwtSecret;

    @Autowired
    protected AppConfigProperties appConfig;

    @PostConstruct
    public void init() {
        jwtSecret = appConfig.token.jwtSecret;
    }


    public void validateToken(String authToken) throws UnauthorizedException {
        try {
            Jwts.parser().setSigningKey(jwtSecret).parseClaimsJws(authToken);
        } catch (MalformedJwtException ex) {
            System.out.println(System.err.printf("Invalid JWT token: %s", authToken));
            throw new UnauthorizedException("Invalid token.");
        } catch (ExpiredJwtException ex) {
            System.out.println(System.err.printf("Expired JWT token: %s", authToken));
            throw new UnauthorizedException("Expired token.");
        } catch (UnsupportedJwtException ex) {
            System.out.println(System.err.printf("Unsupported JWT token: %s", authToken));
            throw new UnauthorizedException("Unsupported token.");
        } catch (IllegalArgumentException ex) {
            System.out.println(System.err.printf("JWT claims string is empty for token: %s", authToken));
            throw new UnauthorizedException("Clams string is empty.");
        }
    }

}
