package com.vzsme.controllerService;

import com.vzsme.controllerService.model.AppProperties.*;
import org.springframework.context.annotation.Configuration;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Configuration
@ConfigurationProperties(prefix = "controller", ignoreInvalidFields = true )
public class AppConfigProperties {

    public Props props = new Props();
    public DatabaseProps db = new DatabaseProps();
    public LdapServerProps ldap = new LdapServerProps();
    public TokenProps token = new TokenProps();


    // NOTE: the setter must match the property name in the application.properties file
    public void setProps(Props props) { this.props = props; }
    public void setDatabase(DatabaseProps db) { this.db = db; }
    public void setLdapServer(LdapServerProps ldap) { this.ldap = ldap; }
    public void setToken(TokenProps token) { this.token = token; }
}
