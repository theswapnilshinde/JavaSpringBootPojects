package com.vzsme.controllerService.model.AppProperties;

import org.springframework.stereotype.Component;

@Component
public class Props {
    //
    // Static generic properties
    //
    private String version = "22.02.09";
    private String name = "Account Management Service";
    private String description = "Account Management Service for Netprizm";

    //
    // Overridable properties from file: application.properties
    //
    private int maxThreads = 2;


    // NOTE: These do NOT have setter methods because they should not be overridden.
    // This is because these properties are used by Swagger and the application.properties
    // are not loaded when
    public String getVersion() { return this.version; }
    public String getName() { return this.name; }
    public String getDescription() { return this.description; }


    //
    // Application.properties: controller.props.XXXX
    // NOTE: The setter must match the property name so the framework can auto-load
    //
    public int getMaxThreads() { return this.maxThreads; }
    public void setMaxThreads(int value) { this.maxThreads = value; }


}
