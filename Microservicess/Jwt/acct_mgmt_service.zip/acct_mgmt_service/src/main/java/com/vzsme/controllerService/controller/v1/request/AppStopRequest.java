package com.vzsme.controllerService.controller.v1.request;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

public class AppStopRequest {

    @NotNull(message = "is required")
    @Valid public int id;

    public void validateInput() {
        //throw new InvalidInputException(">>> TESTING <<<<<");
    }
}
