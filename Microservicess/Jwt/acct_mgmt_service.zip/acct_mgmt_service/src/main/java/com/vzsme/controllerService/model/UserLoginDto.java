package com.vzsme.controllerService.model;

import java.util.Date ;

public class UserLoginDto {
    public int id;
    public Boolean isActive;
    public Boolean pwdNeedsReset;
    public String userFirstName;
    public String userLastName;
    public String loginName;
    public String token;
    public Date lastLoginUTC;
    public Date tokenExpireDateUTC;
}
