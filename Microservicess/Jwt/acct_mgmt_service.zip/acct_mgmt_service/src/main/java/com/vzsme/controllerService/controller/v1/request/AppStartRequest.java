package com.vzsme.controllerService.controller.v1.request;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

public class AppStartRequest {
    @NotNull(message = "is required")
    @Valid public int runId = 101;

    @NotNull(message = "is required")
    @Valid public Integer duNum;

    public void validateInput() {
        //throw new InvalidInputException(">>> TESTING <<<<<");
    }

    public String makeDuName() {
        return (duNum != null ? String.format("DU_%02d", duNum) : "DU");
    }
}
