package com.vzsme.controllerService.controller.v1;


import com.vzsme.controllerService.controller.v1.request.AppStartRequest;
import com.vzsme.controllerService.controller.v1.request.AppStopRequest;
import com.vzsme.controllerService.controller.v1.request.CreateUserRequest;
import com.vzsme.controllerService.controller.v1.request.UserLoginRequest;
import com.vzsme.controllerService.controller.v1.response.UserLoginResponse;
import com.vzsme.controllerService.service.AccountService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@Validated
@RestController
@Api(tags = "Account-Controller", description="API Commands")
public class AccountController extends VersionController {

    @Autowired
    private AccountService service;

    ////////////////////////////////////////////////////////////////////////////////////////////////
    // Create User
    ////////////////////////////////////////////////////////////////////////////////////////////////
    @ApiOperation(value = "Create User")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK"),
            @ApiResponse(code = 401, message = "Unauthorized"),
    })
    @RequestMapping(value = UriConstantsV1.users + "/create", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK) // 200 - Sync call completed successfully
    public UserLoginResponse login( // NOTE: The function name shows in Swagger Spec
                                    HttpServletRequest request,
                                    @Valid @RequestBody CreateUserRequest requestBody // @Valid can throw InvalidInputException
    ) {
        return service.createUser(requestBody);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////
    // User Login
    ////////////////////////////////////////////////////////////////////////////////////////////////
    @ApiOperation(value = "User Login")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK"),
            @ApiResponse(code = 401, message = "Unauthorized"),
    })
    @RequestMapping(value = UriConstantsV1.users + "/login", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK) // 200 - Sync call completed successfully
    public UserLoginResponse login( // NOTE: The function name shows in Swagger Spec
                                    HttpServletRequest request,
                                    @Valid @RequestBody UserLoginRequest requestBody // @Valid can throw InvalidInputException
    ) {
        return service.loginUser(requestBody);
    }

}