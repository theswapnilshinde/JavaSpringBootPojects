package com.verizon.authentication.model;

import lombok.Data;

public class UserData {
    private String userName;
    private String password;
    public static String roleName;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

}
