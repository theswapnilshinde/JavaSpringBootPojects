package com.vzsme.controllerService.controller.v1;

public class BaseController {

    protected String getLikeQueryParams(String queryParams) {

        if (queryParams != null) {
            String[] params = queryParams.split("&");
            for (int ndx = 0; ndx < params.length; ndx++) {

            }
        }
        return "";

    }
}
