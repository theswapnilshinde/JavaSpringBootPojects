package com.ldapauth.common.dto;

import lombok.Data;

@Data
public class UserResData {
	String userName;
	String roleName;
	String password;
}
