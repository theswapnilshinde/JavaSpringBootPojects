package com.ldapauth.service;

import org.springframework.security.core.userdetails.UserDetailsService;

public interface LoginService extends UserDetailsService{

}
