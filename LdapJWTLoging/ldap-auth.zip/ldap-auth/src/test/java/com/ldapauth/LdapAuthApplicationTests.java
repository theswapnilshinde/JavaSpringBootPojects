package com.ldapauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LdapAuthApplicationTests {

	@Test
	void contextLoads() {
	}

}
