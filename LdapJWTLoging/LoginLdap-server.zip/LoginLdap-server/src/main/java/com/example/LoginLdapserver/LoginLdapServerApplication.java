package com.example.LoginLdapserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginLdapServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginLdapServerApplication.class, args);
	}
}
