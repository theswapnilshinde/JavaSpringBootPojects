package com.example.LoginLdapserver.repo;

import com.example.LoginLdapserver.Person;

public interface RepoAdditional {
	
	 String create(Person p);

}
