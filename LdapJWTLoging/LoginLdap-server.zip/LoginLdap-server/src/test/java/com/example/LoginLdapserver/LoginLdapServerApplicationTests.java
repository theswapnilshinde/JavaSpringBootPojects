package com.example.LoginLdapserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginLdapServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
