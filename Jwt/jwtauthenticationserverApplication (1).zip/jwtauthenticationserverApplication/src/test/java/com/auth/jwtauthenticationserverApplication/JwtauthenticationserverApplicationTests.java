package com.auth.jwtauthenticationserverApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtauthenticationserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
